const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('rigorsetDesktopNative', {
  isNativeDesktopApp: true,
  executeOperation: (operationId) => ipcRenderer.invoke('execute-operation', operationId),
});
