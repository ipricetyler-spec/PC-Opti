const { app, BrowserWindow, shell, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');

let mainWindow;
let serverProcess = null;

// Allowlist of strict, audited PowerShell operations
const ALLOWED_OPERATIONS = {
  ENABLE_MEMORY_COMPRESSION: 'Enable-MMAgent -MemoryCompression',
  DISABLE_MEMORY_COMPRESSION: 'Disable-MMAgent -MemoryCompression',
  ENABLE_HAGS: 'Set-ItemProperty -Path "HKLM:\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers" -Name "HwSchMode" -Value 2',
  DISABLE_HAGS: 'Set-ItemProperty -Path "HKLM:\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers" -Name "HwSchMode" -Value 1',
  TRIM_SSD: 'Optimize-Volume -DriveLetter C -Defrag -ReTrim -Verbose',
  CLEAR_TEMP_FILES: 'Get-ChildItem -Path $env:TEMP -Recurse -Force -ErrorAction SilentlyContinue | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue',
  SET_AUTOMATIC_PAGEFILE: 'Set-CimInstance -Query "Select * from Win32_ComputerSystem" -Property @{AutomaticManagedPagefile = $true}',
  ENABLE_NAGLE_OFF: 'Set-ItemProperty -Path "HKLM:\\SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters\\Interfaces\\*" -Name "TcpAckFrequency" -Value 1',
  DISABLE_NAGLE_OFF: 'Remove-ItemProperty -Path "HKLM:\\SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters\\Interfaces\\*" -Name "TcpAckFrequency"',
  CLEAR_DELIVERY_OPTIMIZATION: 'Stop-Service wuauserv -ErrorAction SilentlyContinue; Remove-Item -Path "C:\\Windows\\SoftwareDistribution\\Download\\*" -Recurse -Force -ErrorAction SilentlyContinue; Start-Service wuauserv -ErrorAction SilentlyContinue',
  GET_SYSTEM_VITALS: 'Get-CimInstance Win32_OperatingSystem | Select-Object FreePhysicalMemory, TotalVisibleMemorySize | ConvertTo-Json',
};

function startBackendServer() {
  const serverCjsPath = path.join(__dirname, '../dist/server.cjs');
  if (fs.existsSync(serverCjsPath)) {
    try {
      serverProcess = spawn(process.execPath, [serverCjsPath], {
        env: {
          ...process.env,
          PORT: '3000',
          HOST: '127.0.0.1',
          NODE_ENV: 'production',
        },
        stdio: 'ignore',
      });
      console.log('[Electron Main] Launched local API server on 127.0.0.1:3000');
    } catch (err) {
      console.error('[Electron Main] Failed to launch local server:', err);
    }
  }
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1380,
    height: 900,
    minWidth: 1024,
    minHeight: 700,
    title: 'Rigorset Owner Edition - Windows 11 PC Optimization Platform',
    icon: path.join(__dirname, '../public/favicon.ico'),
    autoHideMenuBar: true,
    backgroundColor: '#0a0b0d',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: false,
    },
  });

  const distIndexPath = path.join(__dirname, '../dist/index.html');

  if (process.env.VITE_DEV_SERVER_URL) {
    mainWindow.loadURL(process.env.VITE_DEV_SERVER_URL);
  } else if (fs.existsSync(distIndexPath)) {
    mainWindow.loadURL('http://127.0.0.1:3000');
  } else {
    mainWindow.loadURL('http://127.0.0.1:3000');
  }

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
}

// Secure IPC Handler using Strict Operation Allowlist
ipcMain.handle('execute-operation', async (event, operationId) => {
  const scriptContent = ALLOWED_OPERATIONS[operationId];
  if (!scriptContent) {
    return {
      success: false,
      error: `Security Violation: Operation ID '${operationId}' is not in the system allowlist.`,
    };
  }

  return new Promise((resolve) => {
    const ps = spawn('powershell.exe', [
      '-NoProfile',
      '-ExecutionPolicy',
      'Bypass',
      '-Command',
      scriptContent,
    ]);

    let stdout = '';
    let stderr = '';

    ps.stdout.on('data', (data) => {
      stdout += data.toString();
    });

    ps.stderr.on('data', (data) => {
      stderr += data.toString();
    });

    ps.on('close', (code) => {
      if (code === 0) {
        resolve({ success: true, output: stdout.trim() || 'Command executed successfully.' });
      } else {
        resolve({
          success: false,
          error: stderr.trim() || stdout.trim() || `Process exited with code ${code}`,
        });
      }
    });
  });
});

app.whenReady().then(() => {
  startBackendServer();
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('before-quit', () => {
  if (serverProcess) {
    serverProcess.kill();
  }
});
